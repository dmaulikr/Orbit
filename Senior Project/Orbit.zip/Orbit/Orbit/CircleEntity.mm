//
//  CircleEntity.m
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import "CircleEntity.h"


@implementation CircleEntity

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = ENTITY_TYPE_CIRCLE;
        
        self->rotation = 0.0;
        
        CGSize screenSize = [CCDirector sharedDirector].winSize;
        self->centerPoint.x = screenSize.width / 2;
        self->centerPoint.y = screenSize.height / 2;
        
        if (screenSize.width < screenSize.height) // assume sprite is square
            self->radius = screenSize.width / 2 - (self.sprite.contentSize.width / 2);
        else
            self->radius = screenSize.height / 2 - (self.sprite.contentSize.width / 2);
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
    self->rotation += self.speed;
    
    if (self->rotation >= 360) {
        self->rotation-=360;
    }
    
    float rotInRad = (M_PI/180) * self->rotation;
    
    CGFloat x = cos(rotInRad);
    CGFloat y = sin(rotInRad);
    
    x *= self->radius;
    y *= self->radius;
    
    self.sprite.position = CGPointMake(self->centerPoint.x + x, self->centerPoint.y + y);
    self.healthSprite.position = self.sprite.position;
    
    [self.primaryWeapon updatePosition: dt];
}

- (void) dealloc {
    [super dealloc];
}
@end
