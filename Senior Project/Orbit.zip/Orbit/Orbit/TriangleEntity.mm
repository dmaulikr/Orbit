//
//  TriangleEntity.m
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import "TriangleEntity.h"


@implementation TriangleEntity
@synthesize heightIncrement = heightIncrement_, widthIncrement = widthIncrement_, topRightDirection = topRightDirection_, 
    bottomRightDirection = bottomRightDirection_, middleLeftDirection = middleLeftDirection_;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = ENTITY_TYPE_TRIANGLE;

        CGSize screenSize = [[CCDirector sharedDirector] winSize];
        // m = (sh - sh/2 /sw) also accounting for the fact that sh - tri.content.h/2
        self.heightIncrement = ((screenSize.height - (self.sprite.contentSize.height / 2)) 
                                - ((screenSize.height - (self.sprite.contentSize.height / 2)) / 2)) / screenSize.width;
        self.widthIncrement = 1.0f;
        
        self.topRightDirection = NO;
        self.bottomRightDirection = NO;
        self.middleLeftDirection = NO;
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    
    CGFloat xPos = self.sprite.position.x;
    CGFloat yPos = self.sprite.position.y;
    
    if (xPos + (self.sprite.contentSize.width / 2) >= screenSize.width) {
        if (yPos + (self.sprite.contentSize.height / 2) >= screenSize.height) {
            self.topRightDirection = NO;
            self.bottomRightDirection = YES;
            self.middleLeftDirection = NO;
        } else if (yPos - (self.sprite.contentSize.height / 2) <= 0.0f) {
            self.topRightDirection = NO;
            self.bottomRightDirection = NO;
            self.middleLeftDirection = YES;   
        } else { // in between
            self.topRightDirection = NO;
            self.bottomRightDirection = YES;
            self.middleLeftDirection = NO;
        }
    } else if (xPos - (self.sprite.contentSize.width / 2) <= 0.0f) {
        self.topRightDirection = YES;
        self.bottomRightDirection = NO;
        self.middleLeftDirection = NO;
    }
    
    if (self.topRightDirection) {
        xPos += self.widthIncrement * self.speed;
        yPos += self.heightIncrement * self.speed; 
    } else if (self.bottomRightDirection) {
        yPos -= self.speed;
    } else if (self.middleLeftDirection) {
        xPos -= self.widthIncrement * self.speed;
        yPos += self.heightIncrement * self.speed; 
    }
    
    self.sprite.position = CGPointMake(xPos, yPos);
    self.healthSprite.position = self.sprite.position;
}

- (void) dealloc {
    [super dealloc];
}
@end
