//
//  PlusEntity.m
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import "PlusEntity.h"


@implementation PlusEntity
@synthesize topRightDirection = topRightDirection_, topLeftDirection = topLeftDirection_, bottomRightDirection = bottomRightDirection_, 
    bottomLeftDirection = bottomLeftDirection_, inwardDirection = inwardDirection_, isInCenter = isInCetner_;
@synthesize heightIncrement, widthIncrement;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = ENTITY_TYPE_PLUS;
        
        CGSize screenSize = [[CCDirector sharedDirector] winSize];
        if (screenSize.width > screenSize.height) {
            self.heightIncrement = screenSize.height/screenSize.width;
            self.widthIncrement = 1.0f;
        } else {
            self.heightIncrement = 1.0f;
            self.widthIncrement = screenSize.width/screenSize.height;
        }
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
    CGPoint pos = self.sprite.position;
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    CGFloat plusSize = self.sprite.contentSize.width / 2;
    
    // At center, switch directions
    if (pos.x <= (screenSize.width / 2) + plusSize / 2
        && pos.x >= (screenSize.width / 2) - plusSize / 2
        && pos.y <= (screenSize.height / 2) + plusSize / 2
        && pos.y >= (screenSize.height / 2) - plusSize / 2) {
        
        if (!self.isInCenter) {
            if (self.topLeftDirection) {
                self.topLeftDirection = NO;
                self.topRightDirection = YES;
            } else if (self.topRightDirection) {
                self.topRightDirection = NO;
                self.bottomRightDirection = YES;
            } else if (self.bottomLeftDirection) {
                self.bottomLeftDirection = NO;
                self.topLeftDirection = YES;
            } else if (self.bottomRightDirection) {
                self.bottomRightDirection = NO;
                self.bottomLeftDirection = YES;
            }
            
            self.inwardDirection = YES;
            self.isInCenter = YES;
        }
    } else if (pos.x >= (screenSize.width - plusSize) && pos.y >= (screenSize.height - plusSize)) { // at top right
        // error correction
        self.topLeftDirection = NO;
        self.topRightDirection = YES;
        self.bottomLeftDirection = NO;
        self.bottomRightDirection = NO;
        
        self.inwardDirection = NO;
    } else if (pos.x <= (0.0f + plusSize) && pos.y >= (screenSize.height - plusSize)) { // at top left
        // error correction
        self.topLeftDirection = YES;
        self.topRightDirection = NO;
        self.bottomLeftDirection = NO;
        self.bottomRightDirection = NO;
        
        self.inwardDirection = NO;
    } else if (pos.x >= (screenSize.width - plusSize) && pos.y <= (0.0f + plusSize)) { // at bottom right
        // error correction
        self.topLeftDirection = NO;
        self.topRightDirection = NO;
        self.bottomLeftDirection = NO;
        self.bottomRightDirection = YES;
        
        self.inwardDirection = NO;
    } else if (pos.x <= (0.0f + plusSize) && pos.y <= (0.0f + plusSize)) { // at bottom left
        // error correction
        self.topLeftDirection = NO;
        self.topRightDirection = NO;
        self.bottomLeftDirection = YES;
        self.bottomRightDirection = NO;
        
        self.inwardDirection = NO;
    } else {
        self.isInCenter = NO;
    }
    
    if (self.topLeftDirection) {
        if (self.inwardDirection)
            self.sprite.position = CGPointMake(pos.x - self.widthIncrement, pos.y + self.heightIncrement);
        else
            self.sprite.position = CGPointMake(pos.x + self.widthIncrement, pos.y - self.heightIncrement);
    } else if (self.topRightDirection) {
        if (self.inwardDirection)
            self.sprite.position = CGPointMake(pos.x + self.widthIncrement, pos.y + self.heightIncrement);
        else
            self.sprite.position = CGPointMake(pos.x - self.widthIncrement, pos.y - self.heightIncrement);
    } else if (self.bottomLeftDirection) {
        if (self.inwardDirection)
            self.sprite.position = CGPointMake(pos.x - self.widthIncrement, pos.y - self.heightIncrement);
        else
            self.sprite.position = CGPointMake(pos.x + self.widthIncrement, pos.y + self.heightIncrement);
    } else if (self.bottomRightDirection) {
        if (self.inwardDirection)
            self.sprite.position = CGPointMake(pos.x + self.widthIncrement, pos.y - self.heightIncrement);
        else 
            self.sprite.position = CGPointMake(pos.x - self.widthIncrement, pos.y + self.heightIncrement);
    }
    
    self.healthSprite.position = self.sprite.position;
}

- (void) dealloc {
    [super dealloc];
}
@end
