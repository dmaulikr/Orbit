//
//  WeaponEntity.m
//  Orbit
//
//  Created by Ken Hung on 1/13/12.
//  Copyright (c) 2012 Cal Poly - SLO. All rights reserved.
//

#import "WeaponEntity.h"

@interface WeaponEntity (AnimateMethods)
    - (void) updatePositionCircular:(ccTime)dt;
    - (void) updatePositionElipse:(ccTime)dt;
    - (void) updatePositionSprialSling:(ccTime)dt;
    - (void) updatePositionLissajousCurve:(ccTime)dt;
    - (void) updatePositionWithPoint: (CGPoint) point;
@end

@implementation WeaponEntity
@synthesize protectee = protectee_, rotation = rotation_, orbitDistance = orbitDistance_, rotateClockwise = rotateClockwise;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side entityType: (EntityType) type;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = type;
        self.speed = 1.0;
        self.protectee = nil;
        self.orbitDistance = 10;
        self.rotateClockwise = NO;
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
    if (self.protectee) {
        [self updatePositionCircular: dt];
       // [self updatePositionElipse: dt];
        //[self updatePositionSprialSling: dt];
        //[self updatePositionLissajousCurve: dt];
    }
}

- (void) dealloc {
    protectee_ = nil;
    [super dealloc];
}

#pragma mark --
#pragma mark AnimateMethods
- (void) updatePositionCircular:(ccTime)dt {
    self.rotation += self.speed;
    if (self.rotation >= 360) {
        self.rotation-=360;
    }
    
    float rotInRad = (M_PI/180) * self.rotation;
    
    CGFloat x = cos(rotInRad);
    CGFloat y = sin(rotInRad);
    
    [self updatePositionWithPoint: CGPointMake(x, y)];
}

- (void) updatePositionElipse:(ccTime)dt {
    CGFloat xRadius = 2, yRadius = 1;
    
    self.rotation += (self.speed * 0.7);
    if (self.rotation >= 360) {
        self.rotation-=360;
    }
    
    float rotInRad = (M_PI/180) * self.rotation;
    
    CGFloat x = xRadius * cos(rotInRad);
    CGFloat y = yRadius * sin(rotInRad);
    
    [self updatePositionWithPoint: CGPointMake(x, y)];
}

- (void) updatePositionSprialSling:(ccTime)dt {
    CGFloat xRadius = 1, yRadius = 1;
    
    // BUG: orbitDistance causes weapon player collision due to it's dependance on speed
    if (!self.rotateClockwise) {
        self.orbitDistance += ((xRadius / (360 * 2)) * 80) * fabs((self.speed * 0.4));
        self.rotation += (self.speed * 0.3) + self.orbitDistance * 0.1;
    } else {
        self.orbitDistance -= ((xRadius / (360 * 2)) * 80) * fabs((self.speed * 0.4));
        self.rotation -= (self.speed * 0.4) + self.orbitDistance * 0.1;
    }
    
    if (self.rotation >= 360 * 2 || self.rotation <= 0) {
        self.rotateClockwise = !self.rotateClockwise;
    }
    
    float rotInRad = (M_PI/180) * self.rotation;
    
    CGFloat x = xRadius * cos(rotInRad);
    CGFloat y = yRadius * sin(rotInRad);
    
    [self updatePositionWithPoint: CGPointMake(x, y)];
}

- (void) updatePositionLissajousCurve:(ccTime)dt {
    self.rotation += (self.speed * 0.4);
    if (self.rotation >= 360) {
        self.rotation-=360;
    }
    
    CGFloat x, y, A, B, Wx, Wy, Sx, Sy;
    
    A = 2;
    B = 2;
    Wx = 3;
    Wy = 1;
    Sx = 0;
    Sy = 0;
    
    float rotInRad = (M_PI/180) * self.rotation;
    
    x = A * cos(2 * rotInRad) + 0.5 * cos(19 * rotInRad);//A * cos(Wx * rotInRad - Sx);
    y = B * sin(2 * rotInRad) + 0.5 * sin(17 * rotInRad);//B * sin(Wy * rotInRad - Sy);
    
    [self updatePositionWithPoint: CGPointMake(x, y)];
}

- (void) updatePositionWithPoint: (CGPoint) point {
    CCSprite * playerSprite = self.protectee.sprite;
    CCSprite * playerWeaponSprite = self.sprite;
    
    // contentSize remains the same no matter scales or rotates
    // 10  buffer
    point.x *= (playerSprite.contentSize.width * playerSprite.scale) / 2 + (playerWeaponSprite.contentSize.width * playerWeaponSprite.scale) / 2 + self.orbitDistance;
    point.y *= (playerSprite.contentSize.height * playerSprite.scale) / 2 + (playerWeaponSprite.contentSize.height * playerWeaponSprite.scale) / 2 + self.orbitDistance;
    //  NSLog(@"x: %f y: %f", x, y);
    
    playerWeaponSprite.position = CGPointMake(playerSprite.position.x + point.x, playerSprite.position.y + point.y);
    
    self.healthSprite.position = self.sprite.position;
}

@end
