//
//  HelloWorldLayer.mm
//  Orbit
//
//  Created by Ken Hung on 8/20/11.
//  Copyright Cal Poly - SLO 2011. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"
#import "Enums.h"
#import "Entity.h"
#import "SquareEntity.h"
#import "CircleEntity.h"
#import "PlusEntity.h"
#import "LineEntity.h"
#import "TriangleEntity.h"
#import "PathedEntity.h"

#import "OrbitShopLayer.h"
#import "MenuLayer.h"
#import "WinScreenLayer.h"

#import "Utils.h"
#import "Vector3D.h"
#import "GameHelper.h"
#import "GameObject.h"
#import "ObjectEntity.h"

#define VICTORY_KILL_NUM 3

// enums that will be used as tags
enum {
	kTagTileMap = 1,
	kTagBatchNode = 1,
	kTagAnimation1 = 1,
};


// HelloWorldLayer implementation
@implementation HelloWorldLayer
@synthesize entities = entities_, playerEntity = playerEntity_, playerWeaponEntity = playerWeaponEntity_, scoreLabel = scoreLabel_,
score = score_, weaponSpeedLabel = weaponSpeedLabel_, weaponDamageLabel = weaponDamageLabel_, pathGrid = pathGrid_, streak = streak_, goalScore = goalScore_;

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

UITapGestureRecognizer * tappy, *tappy2;

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
        
		// enable touches
		self.isTouchEnabled = YES;
        
		// enable accelerometer
	//	self.isAccelerometerEnabled = YES;
		
		CGSize screenSize = [CCDirector sharedDirector].winSize;
		CCLOG(@"Screen width %0.2f screen height %0.2f",screenSize.width,screenSize.height);
		
		// Define the gravity vector.
		b2Vec2 gravity;
	//	gravity.Set(0.0f, -10.0f);
        gravity.Set(0.0f, 0.0f);
		
		// Do we want to let bodies sleep?
		// This will speed up the physics simulation
	//	bool doSleep = true;
        bool doSleep = false;
		
		// Construct a world object, which will hold and simulate the rigid bodies.
		world = new b2World(gravity, doSleep);
		
		world->SetContinuousPhysics(true);
        
        listener = new MyContactListener();
        world->SetContactListener(listener);
    
		// Debug Draw functions
		m_debugDraw = new GLESDebugDraw( PTM_RATIO );
		world->SetDebugDraw(m_debugDraw);
		
		uint32 flags = 0;
		flags += b2DebugDraw::e_shapeBit;
//		flags += b2DebugDraw::e_jointBit;
//		flags += b2DebugDraw::e_aabbBit;
//		flags += b2DebugDraw::e_pairBit;
//		flags += b2DebugDraw::e_centerOfMassBit;
		m_debugDraw->SetFlags(flags);		
		
		
		// Define the ground body.
		b2BodyDef groundBodyDef;
		groundBodyDef.position.Set(0, 0); // bottom-left corner
		
		// Call the body factory which allocates memory for the ground body
		// from a pool and creates the ground box shape (also from a pool).
		// The body is also added to the world.
		b2Body* groundBody = world->CreateBody(&groundBodyDef);
		
		// Define the ground box shape.
		b2PolygonShape groundBox;		
		
		// bottom
		groundBox.SetAsEdge(b2Vec2(0,0), b2Vec2(screenSize.width/PTM_RATIO,0));
		groundBody->CreateFixture(&groundBox,0);
		
		// top
		groundBox.SetAsEdge(b2Vec2(0,screenSize.height/PTM_RATIO), b2Vec2(screenSize.width/PTM_RATIO,screenSize.height/PTM_RATIO));
		groundBody->CreateFixture(&groundBox,0);
		
		// left
		groundBox.SetAsEdge(b2Vec2(0,screenSize.height/PTM_RATIO), b2Vec2(0,0));
		groundBody->CreateFixture(&groundBox,0);
		
		// right
		groundBox.SetAsEdge(b2Vec2(screenSize.width/PTM_RATIO,screenSize.height/PTM_RATIO), b2Vec2(screenSize.width/PTM_RATIO,0));
		groundBody->CreateFixture(&groundBox,0);
		
		
		//Set up sprite
		/*
		CCSpriteBatchNode *batch = [CCSpriteBatchNode batchNodeWithFile:@"blocks.png" capacity:150];
		[self addChild:batch z:0 tag:kTagBatchNode];
		
		[self addNewSpriteWithCoords:ccp(screenSize.width/2, screenSize.height/2)];
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Tap screen" fontName:@"Marker Felt" fontSize:32];
		[self addChild:label z:0];
		[label setColor:ccc3(0,0,255)];
		label.position = ccp( screenSize.width/2, screenSize.height-50);
		*/
        
        // Score
        self.score = 1600;//10000;
        self.goalScore = 2000;
        
        self.scoreLabel = [CCLabelTTF labelWithString: @"0" fontName: @"Arial" fontSize:22];
        [self.scoreLabel setColor:ccc3(255, 255, 255)];
        self.scoreLabel.position = ccp(120, screenSize.height - 10);
        [self addChild: self.scoreLabel z: 1];
        
        // Weapon Stats
        self.weaponDamageLabel = [CCLabelTTF labelWithString:@"W Damage: -" fontName: @"Arial" fontSize: 22];
        [self.weaponDamageLabel setColor: ccc3(255, 255, 255)];
        self.weaponDamageLabel.position = ccp(screenSize.width - 120, screenSize.height - 10);
        [self addChild: self.weaponDamageLabel z: 1];
        
        self.weaponSpeedLabel = [CCLabelTTF labelWithString: @"W Speed: -" fontName: @"Arial" fontSize: 22];
        [self.weaponSpeedLabel setColor:ccc3(255, 255, 255)];
        self.weaponSpeedLabel.position = ccp(self.weaponDamageLabel.position.x - 180, screenSize.height - 10);
        [self addChild: self.weaponSpeedLabel z: 1];

        // Inititalize list of entities
        self.entities = [[NSMutableArray alloc] init];
        
        // Add Grid Layer
        self.pathGrid = [[GridLayer alloc] initWithScreenWidths: 4];
        
        // Add some geometry
        [self addRandomPolygons: 8];
        [self addRandomBoxes: 7];
        
        // Cull grid with world geoemtry
        [self.pathGrid cullGridWithWorld: world];
        [self addChild: self.pathGrid z:0];
        
        spawnCount = 0;
        hasSpawnedBoss = NO;
        bossKillCount = 0;
        hasReachedScore = NO;
        
        [self initPlayer];
        
      //  [self initLine];
      //  [self initPlus];
      //  [self initSquare];
      //  [self initTriangle];
        
      //  [self schedule: @selector(initLine) interval: 1.0];
        [self schedule: @selector(initPlus) interval: 5.0];
        [self schedule: @selector(initSquare) interval: 3.0];
        [self schedule: @selector(initTriangle) interval: 4.0];
        [self initCircle];
        
      //  [self schedule: @selector(initCircle) interval: 5.0];
      //  [self schedule: @selector(initPathed) interval:3.0];
      //  [self initPathed];
        
        [self schedule: @selector(updateEntitiesPosition:)];
   //     [self schedule: @selector(updateWeaponPosition:)];
        // Sync sprite positions with box positions
        [self schedule: @selector(updateSpriteToBox:)];
        [self schedule: @selector(tick:)];

#ifndef ORBIT_DEBUG_DISABLE_SCROLLING
        [self schedule: @selector(updateScrollingNodes)];
#endif

        UITapGestureRecognizer * recognizer = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(handleTap:)];
        recognizer.numberOfTapsRequired = 1;
        recognizer.numberOfTouchesRequired = 1;
        [[[CCDirector sharedDirector] openGLView] addGestureRecognizer: recognizer];
        recognizer.cancelsTouchesInView = NO;
        tappy = [recognizer retain];
        [recognizer release];
        
        recognizer = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(handleTapTwo:)];
        recognizer.numberOfTapsRequired = 1;
        recognizer.numberOfTouchesRequired = 2;
        [[[CCDirector sharedDirector] openGLView] addGestureRecognizer: recognizer];
        recognizer.cancelsTouchesInView = NO;
        tappy2 = [recognizer retain];
        [recognizer release];
        
        CCMenuItem * menuItem = [CCMenuItemFont itemFromString:@"Menu" target:self selector :@selector(onMenu:)];
        menuItem.position = ccp(screenSize.width / 2, screenSize.height - 10);
        CCMenu *menu = [CCMenu menuWithItems:menuItem, nil];
        menu.position = CGPointZero;
        //   [menu alignItemsVertically];
        [self addChild:menu];
	}
	return self;
}

- (void) stopSpawning {
    [self unschedule:@selector(initPlus)];
    [self unschedule:@selector(initSquare)];
    [self unschedule:@selector(initTriangle)];
    [self unschedule:@selector(initPathed)];
}

- (void) spawnBoss {
    [self schedule: @selector(initPathed) interval:1.5];
    
    hasSpawnedBoss = YES;
}

- (void) onMenu: (id) sender {
    NSLog(@"1");
    [[[CCDirector sharedDirector] openGLView] removeGestureRecognizer:tappy];
    [[[CCDirector sharedDirector] openGLView] removeGestureRecognizer:tappy2];
    
    [tappy release];
    [tappy2 release];
    
    [[CCDirector sharedDirector] replaceScene: [MenuLayer scene]];
}

- (void) handleTap: (UIGestureRecognizer *) gesture {
    CGPoint location = [gesture locationInView: [[CCDirector sharedDirector] openGLView]];
    location = [[CCDirector sharedDirector] convertToGL: location];
    //   NSLog(@"Touch Began");
    
    CCSprite * playerSprite = self.playerEntity.sprite;
    
    // If touch down is within the player
    if (location.x <= (playerSprite.position.x + playerSprite.contentSize.width/2) 
        && location.x >= (playerSprite.position.x - playerSprite.contentSize.width/2)
        && location.y <= (playerSprite.position.y + playerSprite.contentSize.height/2) 
        && location.y >= (playerSprite.position.y - playerSprite.contentSize.height/2)) {
        
        if (self.score - 200 >= 0) {
            self.score-=200;
            [self.scoreLabel setString: [NSString stringWithFormat: @"%d/%d", self.score, self.goalScore]];
            self.playerEntity.primaryWeapon.speed+=0.1;
            [self.weaponSpeedLabel setString: [NSString stringWithFormat: @"W Speed %f", self.playerEntity.primaryWeapon.speed]];
        }
    }
}

- (void) handleTapTwo: (UIGestureRecognizer *) gesture {
    CGPoint location = [gesture locationInView: [[CCDirector sharedDirector] openGLView]];
    location = [[CCDirector sharedDirector] convertToGL: location];
    //   NSLog(@"Touch Began");
    
    CCSprite * playerSprite = self.playerEntity.sprite;
    
    // If touch down is within the player
    if (location.x <= (playerSprite.position.x + playerSprite.contentSize.width/2) 
        && location.x >= (playerSprite.position.x - playerSprite.contentSize.width/2)
        && location.y <= (playerSprite.position.y + playerSprite.contentSize.height/2) 
        && location.y >= (playerSprite.position.y - playerSprite.contentSize.height/2)) {
        
        if (self.score - 300 >= 0) {
            self.score-=300;
            [self.scoreLabel setString: [NSString stringWithFormat: @"%d/%d", self.score, self.goalScore]];
            self.playerWeaponEntity.sprite.scale += 0.05;//0.025;
            
            weaponBody->DestroyFixture(weaponBody->GetFixtureList());
            
            b2CircleShape dynamicBox2;
            //   dynamicBox2.SetAsBox(0.5f, 0.5f);//These are mid points for our 1m box
            dynamicBox2.m_radius = ((self.playerWeaponEntity.sprite.contentSize.width/2) / PTM_RATIO) 
                * self.playerWeaponEntity.sprite.scale;
            // Define the dynamic body fixture.
            b2FixtureDef fixtureDef2;
            fixtureDef2.shape = &dynamicBox2;	
            fixtureDef2.density = 100.0f;
            fixtureDef2.friction = 0.5f;
            weaponBody->CreateFixture(&fixtureDef2);
            //.m_radius = (self.playerWeaponEntity.sprite.contentSize.width/4) / PTM_RATIO;
            
            [self.weaponDamageLabel setString: [NSString stringWithFormat: @"W Damage %f", self.playerWeaponEntity.sprite.scale]];
        }
    }
}

-(void) addNewSpriteWithCoords:(CGPoint)p
{
	CCLOG(@"Add sprite %0.2f x %02.f",p.x,p.y);
	CCSpriteBatchNode *batch = (CCSpriteBatchNode*) [self getChildByTag:kTagBatchNode];
	
	//We have a 64x64 sprite sheet with 4 different 32x32 images.  The following code is
	//just randomly picking one of the images
	int idx = (CCRANDOM_0_1() > .5 ? 0:1);
	int idy = (CCRANDOM_0_1() > .5 ? 0:1);
	CCSprite *sprite = [CCSprite spriteWithBatchNode:batch rect:CGRectMake(32 * idx,32 * idy,32,32)];
	[batch addChild:sprite];
	
	sprite.position = ccp( p.x, p.y);
	
	// Define the dynamic body.
	//Set up a 1m squared box in the physics world
	b2BodyDef bodyDef;
	bodyDef.type = b2_dynamicBody;
    
	bodyDef.position.Set(p.x/PTM_RATIO, p.y/PTM_RATIO);
	bodyDef.userData = sprite;
	b2Body *body = world->CreateBody(&bodyDef);
	
	// Define another box shape for our dynamic body.
	b2PolygonShape dynamicBox;
	dynamicBox.SetAsBox(.5f, .5f);//These are mid points for our 1m box
	
	// Define the dynamic body fixture.
	b2FixtureDef fixtureDef;
	fixtureDef.shape = &dynamicBox;	
	fixtureDef.density = 1.0f;
	fixtureDef.friction = 0.3f;
	body->CreateFixture(&fixtureDef);
}

- (void) cleanupWeaponRecurse: (Entity *) entity {
    // Make sure we don't try to destroy a weapon if it's already destroyed
    if (entity.primaryWeapon && entity.primaryWeapon.isValid) {
        [self cleanupWeaponRecurse: entity.primaryWeapon];
    }
    
    CGPoint exploPoint = entity.sprite.position;
    
    world->DestroyBody(entity.body);
    [self removeChild: entity.sprite cleanup: YES];
    [self removeChild: entity.healthSprite cleanup:YES];
    [self.entities removeObject: entity];
    
    [self animateParticleDeathAtPosition: exploPoint];
}

- (void) animateParticleDeathAtPosition: (CGPoint) position {
    CCParticleExplosion* explo = [[[CCParticleExplosion alloc] initWithTotalParticles: 100] autorelease];
    explo.autoRemoveOnFinish = YES;
    // Duration animation NOT doesn't affect radius
    explo.duration = 0.1f;
    explo.speed = 200.0f;
    // Seconds per particle to live and it's variance
    explo.life = 0.6f;
    explo.lifeVar = 0.2f;
    explo.startSize = 4.0f;
    explo.endSize = 0.5f;
    explo.position = position;
    
    [self addChild: explo z:0 tag: 984651];
}

#pragma mark
#pragma mark Add Sprites and Objects
- (void) initPlayer {
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    // Setup Circle and circle's weapon
    CCSprite * player = [CCSprite spriteWithFile:@"ph_circle.png" 
                                            rect:CGRectMake(0, 0, 64, 64)];
    player.position = ccp(player.contentSize.width/2, screenSize.height/2);
    player.scale = 0.75;
    [self addChild: player];
    isMoving = NO;
    
    // Wrap sprite in an Entity
    self.playerEntity = [[PlayerEntity alloc] initWithSprite: player entitySide: ENTITY_SIDE_SELF entityType: ENTITY_TYPE_CIRCLE];
    //   [self.entities addObject: circleEntity];
    
    // Define the dynamic body.
    //Set up a 1m squared box in the physics world
    b2BodyDef bodyDef;
    bodyDef.type = b2_dynamicBody;
    
    bodyDef.position.Set(player.position.x/PTM_RATIO, player.position.y/PTM_RATIO);
    bodyDef.userData = self.playerEntity; // entities should keep this alive
    //     [playerEntity release];
    b2Body *body = world->CreateBody(&bodyDef);
    
    // Define another box shape for our dynamic body.
    //   b2PolygonShape dynamicBox;
    b2CircleShape dynamicBox;
    //dynamicBox.SetAsBox(1.0f, 1.0f);//These are mid points for our 1m box
    // dynamicBox.SetAsCircle();
    dynamicBox.m_radius = (player.contentSize.width/2) / PTM_RATIO * player.scale;
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &dynamicBox;	
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.3f;
    fixtureDef.isSensor = true;
    body->CreateFixture(&fixtureDef);
    
    self.playerEntity.body = body;
    
    CCSprite * playerWeapon = [CCSprite spriteWithFile: @"ph_circle.png"
                                                  rect: CGRectMake(0, 0, 64, 64)];
    playerWeapon.position = ccp(player.contentSize.width + playerWeapon.contentSize.width/2, 
                                screenSize.height/2);
    playerWeapon.scale = 0.5f;
    [self addChild: playerWeapon];
    
    self.playerWeaponEntity = [[WeaponEntity alloc] initWithSprite: playerWeapon entitySide: ENTITY_SIDE_SELF | ENTITY_SIDE_WEAPON entityType: ENTITY_TYPE_CIRCLE];
    //    [self.entities addObject: playerWeaponEntity];
    
    self.playerEntity.primaryWeapon = self.playerWeaponEntity;
    self.playerWeaponEntity.speed = 8.0f;
    self.playerWeaponEntity.orbitDistance = 28;
    
    b2BodyDef bodyDef2;
    bodyDef2.type = b2_dynamicBody;
    
    bodyDef2.position.Set(playerWeapon.position.x/PTM_RATIO, playerWeapon.position.y/PTM_RATIO);
    bodyDef2.userData = self.playerWeaponEntity;
    //    [playerWeaponEntity release];
    b2Body *body2 = world->CreateBody(&bodyDef2);
    
    // Define another box shape for our dynamic body.
    //  b2PolygonShape dynamicBox2;
    b2CircleShape dynamicBox2;
    //   dynamicBox2.SetAsBox(0.5f, 0.5f);//These are mid points for our 1m box
    dynamicBox2.m_radius = ((playerWeapon.contentSize.width/2) / PTM_RATIO) * playerWeapon.scale;
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef2;
    fixtureDef2.shape = &dynamicBox2;	
    fixtureDef2.density = 100.0f;
    fixtureDef2.friction = 0.5f;
    body2->CreateFixture(&fixtureDef2);
    
    weaponBody = body2;
    
    self.playerWeaponEntity.body = body2;
    
    // Weapon motion streaking effect
    self.streak = [CCMotionStreak streakWithFade:0.75 minSeg:1 image:@"ph_circle.png" width:64 length:64 color:ccc4(255, 255, 255, 255)];
    self.streak.scale = 0.5f;
    self.streak.position = playerWeapon.position;
    
    [self addChild: self.streak];    
}

- (void) initPathed {
    if (spawnCount >= VICTORY_KILL_NUM) {
        [self stopSpawning];
        return;
    }
    
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    CCSprite * pathed = [CCSprite spriteWithFile: @"ph_line.png" rect: CGRectMake(0, 0, 64, 64)];
    
    pathed.position = ccp(screenSize.width * [self.pathGrid getCurrentScreenNumber] / 2, screenSize.height / 2);
    [self addChild: pathed];
    
    CCSprite * pathedHealth = [CCSprite spriteWithFile: @"ph_line_hp_bar.png" rect: CGRectMake(0, 0, 64, 64)];
    pathedHealth.position = ccp(screenSize.width * [self.pathGrid getCurrentScreenNumber] / 2, screenSize.height / 2);
    [self addChild: pathedHealth];
    
    PathedEntity * pathedEntity = [[PathedEntity alloc] initWithSprite: pathed entitySide: ENTITY_SIDE_ENEMY gameGrid: self.pathGrid];
    pathedEntity.healthSprite = pathedHealth;
    pathedEntity.speed = 4;
    
    [self.entities addObject: pathedEntity];
    
    b2BodyDef bodyDef;
    bodyDef.type = b2_staticBody;
    bodyDef.position.Set(pathed.position.x/PTM_RATIO, pathed.position.y/PTM_RATIO);
    bodyDef.userData = pathedEntity;
    
    b2Body * body = world->CreateBody(&bodyDef);
    
    b2PolygonShape dynamicBox;
    dynamicBox.SetAsBox(1.0f, 0.25f);//These are mid points for our 1m box
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &dynamicBox;	
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.3f;
    fixtureDef.restitution = 1.0f;
    body->CreateFixture(&fixtureDef);
    
    pathedEntity.body = body;
    
    [pathedEntity addWaypoint];
    [pathedEntity release];
    
    spawnCount++;
}

- (void) initLine {
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    CCSprite * line = [CCSprite spriteWithFile: @"ph_line.png" 
                               rect: CGRectMake(0, 0, 64, 64)];
    NSInteger height = arc4random() % ((NSInteger)screenSize.height);
    
    line.position = ccp(screenSize.width - (line.contentSize.width / 2), height /*screenSize.height / 2*/);
    [self addChild: line];
    
    CCSprite * lineHealth = [CCSprite spriteWithFile: @"ph_line_hp_bar.png" 
                                          rect: CGRectMake(0, 0, 64, 64)];
    lineHealth.position = ccp(screenSize.width - (lineHealth.contentSize.width / 2), height /*screenSize.height / 2*/);
    [self addChild: lineHealth];
    
    LineEntity * lineEntity = [[LineEntity alloc] initWithSprite: line entitySide: ENTITY_SIDE_ENEMY];
    lineEntity.healthSprite = lineHealth;
    lineEntity.speed = 2.0;
    lineEntity.leftDirection = YES;
    
    [self.entities addObject: lineEntity];
    
    b2BodyDef bodyDef;
    bodyDef.type = b2_staticBody;
    bodyDef.position.Set(line.position.x/PTM_RATIO, line.position.y/PTM_RATIO);
    bodyDef.userData = lineEntity;

    b2Body * body = world->CreateBody(&bodyDef);
    
    b2PolygonShape dynamicBox;
    dynamicBox.SetAsBox(1.0f, 0.25f);//These are mid points for our 1m box
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &dynamicBox;	
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.3f;
    fixtureDef.restitution = 1.0f;
    body->CreateFixture(&fixtureDef);
    
    lineEntity.body = body;
    [lineEntity release];
}

- (void) initTriangle {
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    CCSprite * triangle = [CCSprite spriteWithFile:@"ph_triangle.png"
                                   rect:CGRectMake(0, 0, 64, 64)];
    triangle.position = ccp(screenSize.width - (triangle.contentSize.width / 2), screenSize.height * (1.0/4.0));
    triangle.rotation = -90;
    [self addChild: triangle];
    
    CCSprite * triangleHealth = [CCSprite spriteWithFile:@"ph_triangle_hp_bar.png"
                                              rect:CGRectMake(0, 0, 64, 64)];
    triangleHealth.position = ccp(screenSize.width - (triangleHealth.contentSize.width / 2), screenSize.height * (1.0/4.0));
    triangleHealth.rotation = -90;
    [self addChild: triangleHealth];
    
    TriangleEntity * triangleEntity = [[TriangleEntity alloc] initWithSprite: triangle entitySide: ENTITY_SIDE_ENEMY];
    triangleEntity.healthSprite = triangleHealth;
    triangleEntity.speed = 4.0f;
    triangleEntity.topRightDirection = YES;
    triangleEntity.bottomRightDirection = NO;
    triangleEntity.middleLeftDirection = NO;
    
    [self.entities addObject: triangleEntity];
    
    b2BodyDef bodyDef4;
    bodyDef4.type = b2_staticBody;//b2_dynamicBody;
    //  bodyDef4.linearVelocity = b2Vec2(-10.0f, 0.0f);
    bodyDef4.position.Set(triangle.position.x/PTM_RATIO, triangle.position.y/PTM_RATIO);
    bodyDef4.userData = triangleEntity;
    
    b2Body *body4 = world->CreateBody(&bodyDef4);
    
    // Define another box shape for our dynamic body.
    b2PolygonShape dynamicBox4;
    CGFloat tri_width = triangle.contentSize.width;
    b2Vec2 verts[] = {
        b2Vec2(0.0f - ((tri_width / 2) / PTM_RATIO), 0.0f - ((tri_width / 2) / PTM_RATIO)),
        b2Vec2((tri_width / PTM_RATIO) - ((tri_width / 2) / PTM_RATIO), 0.0f - ((tri_width / 2) / PTM_RATIO)),
        b2Vec2(((tri_width / 2) / PTM_RATIO) - ((tri_width / 2) / PTM_RATIO), tri_width / PTM_RATIO - ((tri_width / 2) / PTM_RATIO))
    };
    
    dynamicBox4.Set(verts, 3);
    //  dynamicBox4.SetAsBox(1.0f, 1.0f);//These are mid points for our 1m box
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef4;
    fixtureDef4.shape = &dynamicBox4;	
    fixtureDef4.density = 1.0f;
    fixtureDef4.friction = 0.3f;
    fixtureDef4.restitution = 1.0f;
    body4->CreateFixture(&fixtureDef4);
    
    triangleEntity.body = body4;
    [triangleEntity release];
}

- (void) initSquare {
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    CCSprite * square = [CCSprite spriteWithFile:@"ph_square.png"
                                 rect:CGRectMake(0, 0, 64, 64)];
    square.position = ccp(screenSize.width - (square.contentSize.width / 2), screenSize.height / 2);
    [self addChild: square];
    
    CCSprite * squareHealth = [CCSprite spriteWithFile: @"ph_square_hp_bar.png"
                                                  rect:CGRectMake(0, 0, 64, 64)];
    squareHealth.position = ccp(screenSize.width - (squareHealth.contentSize.width / 2), screenSize.height / 2);
    [self addChild:squareHealth];
    
    SquareEntity * squareEntity = [[SquareEntity alloc] initWithSprite: square entitySide: ENTITY_SIDE_ENEMY];
    squareEntity.healthSprite = squareHealth;
    squareEntity.rightDirection = NO;
    squareEntity.leftDirection = NO;
    squareEntity.upDirection = NO;
    squareEntity.downDirection = YES;
    squareEntity.speed = 3.0f;
    
    [self.entities addObject: squareEntity];
    
    b2BodyDef bodyDef3;
    bodyDef3.type = b2_staticBody;//b2_dynamicBody;
    
    bodyDef3.position.Set(square.position.x/PTM_RATIO, square.position.y/PTM_RATIO);
    bodyDef3.userData = squareEntity;
    
    b2Body *body3 = world->CreateBody(&bodyDef3);
    
    // Define another box shape for our dynamic body.
    b2PolygonShape dynamicBox3;
    dynamicBox3.SetAsBox(1.0f, 1.0f);//These are mid points for our 1m box
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef3;
    fixtureDef3.shape = &dynamicBox3;	
    fixtureDef3.density = 1.0f;
    fixtureDef3.friction = 0.3f;
    fixtureDef3.restitution = 1.0f;
    body3->CreateFixture(&fixtureDef3);

    squareEntity.body = body3;
    [squareEntity release];
}

- (void) initPlus {
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    CCSprite * plus = [CCSprite spriteWithFile: @"ph_plus.png" 
                               rect: CGRectMake(0, 0, 64, 64)];
    plus.position = ccp(screenSize.width/2, screenSize.height/2);
    plus.rotation = 45;
    [self addChild: plus];
    
    CCSprite * plusHealth = [CCSprite spriteWithFile: @"ph_plus_hp_bar.png" 
                                          rect: CGRectMake(0, 0, 64, 64)];
    plusHealth.position = ccp(screenSize.width/2, screenSize.height/2);
    plusHealth.rotation = 45;
    [self addChild: plusHealth];
    
    PlusEntity * plusEntity = [[PlusEntity alloc] initWithSprite: plus entitySide: ENTITY_SIDE_ENEMY];
    plusEntity.healthSprite = plusHealth;
    plusEntity.topLeftDirection = NO;
    plusEntity.topRightDirection = YES;
    plusEntity.bottomLeftDirection = NO;
    plusEntity.bottomRightDirection = NO;
    plusEntity.isInCenter = YES;
    plusEntity.inwardDirection = YES;
    
    [self.entities addObject: plusEntity];
    
    b2BodyDef bodyDef5;
    bodyDef5.type = b2_staticBody;//b2_dynamicBody;
    
    bodyDef5.position.Set(plus.position.x/PTM_RATIO, plus.position.y/PTM_RATIO);
    bodyDef5.userData = plusEntity;
    
    b2Body *body5 = world->CreateBody(&bodyDef5);
    
    b2PolygonShape dynamicBoxX1;
    CGFloat plusWidth = plus.contentSize.width / 7;
    CGFloat plusShift = (plus.contentSize.width / 2) / PTM_RATIO;
    b2Vec2 vertsX1[] = {
        b2Vec2(0.0f - plusShift, (plusWidth * 4) / PTM_RATIO - plusShift),
        b2Vec2(0.0f - plusShift, (plusWidth * 3) / PTM_RATIO  - plusShift),
        b2Vec2((plusWidth * 7) / PTM_RATIO - plusShift, (plusWidth * 3) / PTM_RATIO - plusShift),
        b2Vec2((plusWidth * 7) / PTM_RATIO - plusShift, (plusWidth * 4) / PTM_RATIO - plusShift),
    };
    
    dynamicBoxX1.Set(vertsX1, 4);
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDefX1;
    fixtureDefX1.shape = &dynamicBoxX1;	
    fixtureDefX1.density = 1.0f;
    fixtureDefX1.friction = 0.3f;
    fixtureDefX1.restitution = 1.0f;
    body5->CreateFixture(&fixtureDefX1);
    
    b2PolygonShape dynamicBoxX2;
    b2Vec2 vertsX2[] = {
        b2Vec2((plusWidth * 3) / PTM_RATIO - plusShift, 0.0f - plusShift),
        b2Vec2((plusWidth * 4) / PTM_RATIO - plusShift, 0.0f - plusShift),
        b2Vec2((plusWidth * 4) / PTM_RATIO - plusShift, (plusWidth * 7) / PTM_RATIO - plusShift),
        b2Vec2((plusWidth * 3) / PTM_RATIO - plusShift, (plusWidth * 7) / PTM_RATIO - plusShift),
    };
    
    dynamicBoxX2.Set(vertsX2, 4);
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDefX2;
    fixtureDefX2.shape = &dynamicBoxX2;	
    fixtureDefX2.density = 1.0f;
    fixtureDefX2.friction = 0.3f;
    fixtureDefX2.restitution = 1.0f;
    body5->CreateFixture(&fixtureDefX2);
    
    plusEntity.body = body5;
    [plusEntity release];
}

- (void) initCircle {
    CGSize screenSize = [CCDirector sharedDirector].winSize;
    
    // ===== Sprite Creation =====
    
    // Create and add unit sprite
    CCSprite * circle = [CCSprite spriteWithFile: @"ph_circle.png" rect: CGRectMake(0, 0, 64, 64)];
    circle.position = ccp(screenSize.width / 2, screenSize.height - (circle.contentSize.height / 2));
    [self addChild: circle];
    
    // Create and add health sprite
    CCSprite * circleHealth = [CCSprite spriteWithFile: @"ph_circle_hp_bar.png" rect: CGRectMake(0, 0, 64, 64)];
    circleHealth.position = ccp(screenSize.width / 2, screenSize.height - (circleHealth.contentSize.height / 2));
    [self addChild: circleHealth];

    // Wrap sprites into Entities
    CircleEntity * circleEntity = [[CircleEntity alloc] initWithSprite: circle entitySide: ENTITY_SIDE_ENEMY];
    circleEntity.healthSprite = circleHealth;
    circleEntity.speed = 1.0;
    
    // ===== Create Box2D body and fixtures for collision detection =====
    
    // Define the dynamic body.
    b2BodyDef bodyDef;
    bodyDef.type = b2_staticBody;
    
    bodyDef.position.Set(circle.position.x/PTM_RATIO, circle.position.y/PTM_RATIO);
    bodyDef.userData = circleEntity; 
    
    b2Body *body = world->CreateBody(&bodyDef);
    
    // Define another box shape for our dynamic body.
    //   b2PolygonShape dynamicBox;
    b2CircleShape dynamicBox;
    //dynamicBox.SetAsBox(1.0f, 1.0f);//These are mid points for our 1m box
    // dynamicBox.SetAsCircle();
    dynamicBox.m_radius = (circle.contentSize.width/2) / PTM_RATIO;
    
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &dynamicBox;	
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.3f;
    fixtureDef.restitution = 1.0f;
    body->CreateFixture(&fixtureDef);
    
    // Add body to Entity
    circleEntity.body = body;
    
    // Add to Entity Manager
    [self.entities addObject: circleEntity];
    
    // ===== Add Weapon =====
    
    CCSprite * weapon = [CCSprite spriteWithFile: @"ph_circle.png" rect: CGRectMake(0, 0, 64, 64)];
    weapon.position = ccp(circle.contentSize.width + weapon.contentSize.width/2, screenSize.height/2);
    weapon.scale = 0.5f;
    [self addChild: weapon];
    
    CCSprite * weaponHealth = [CCSprite spriteWithFile: @"ph_circle_hp_bar.png" rect: CGRectMake(0, 0, 64, 64)];
    weaponHealth.position = ccp(circle.contentSize.width + weapon.contentSize.width/2, screenSize.height/2);
    weaponHealth.scale = 0.5f;
    [self addChild: weaponHealth];
    
    WeaponEntity * wep = [[WeaponEntity alloc] initWithSprite: weapon entitySide: ENTITY_SIDE_ENEMY | ENTITY_SIDE_WEAPON entityType: ENTITY_TYPE_CIRCLE];
    wep.speed = 2;
    wep.healthSprite = weaponHealth;
    
    b2BodyDef bodyDef2;
    bodyDef2.type = b2_staticBody;
    
    bodyDef2.position.Set(weapon.position.x/PTM_RATIO, weapon.position.y/PTM_RATIO);
    bodyDef2.userData = wep;
    //    [playerWeaponEntity release];
    b2Body *body2 = world->CreateBody(&bodyDef2);
    
    // Define another box shape for our dynamic body.
    //  b2PolygonShape dynamicBox2;
    b2CircleShape dynamicBox2;
    //   dynamicBox2.SetAsBox(0.5f, 0.5f);//These are mid points for our 1m box
    dynamicBox2.m_radius = ((weapon.contentSize.width/2) / PTM_RATIO) * weapon.scale;
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef2;
    fixtureDef2.shape = &dynamicBox2;	
    fixtureDef2.density = 100.0f;
    fixtureDef2.friction = 0.5f;
    body2->CreateFixture(&fixtureDef2);
    
    wep.body = body2;
    
    circleEntity.primaryWeapon = wep;
    
    [self.entities addObject:wep];
    
    [circleEntity release];
    
    // subweapon test
    
    CCSprite * weapon2 = [CCSprite spriteWithFile: @"ph_circle.png" rect: CGRectMake(0, 0, 64, 64)];
    weapon2.position = ccp(weapon.contentSize.width + weapon2.contentSize.width/2, screenSize.height/2);
    weapon.scale = 0.5f;
    [self addChild: weapon2];
    
    CCSprite * weaponHealth2 = [CCSprite spriteWithFile: @"ph_circle_hp_bar.png" rect: CGRectMake(0, 0, 64, 64)];
    weaponHealth2.position = ccp(weapon.contentSize.width + weapon2.contentSize.width/2, screenSize.height/2);
    weaponHealth2.scale = 0.5f;
    [self addChild: weaponHealth2];
    
    WeaponEntity * wep2 = [[WeaponEntity alloc] initWithSprite: weapon2 entitySide: ENTITY_SIDE_ENEMY | ENTITY_SIDE_WEAPON entityType: ENTITY_TYPE_CIRCLE];
    wep2.speed = 6;
    wep2.healthSprite = weaponHealth2;
    
    b2BodyDef bodyDef22;
    bodyDef22.type = b2_staticBody;
    
    bodyDef22.position.Set(weapon2.position.x/PTM_RATIO, weapon2.position.y/PTM_RATIO);
    bodyDef22.userData = wep2;
    //    [playerWeaponEntity release];
    b2Body *body22 = world->CreateBody(&bodyDef22);
    
    // Define another box shape for our dynamic body.
    //  b2PolygonShape dynamicBox2;
    b2CircleShape dynamicBox22;
    //   dynamicBox2.SetAsBox(0.5f, 0.5f);//These are mid points for our 1m box
    dynamicBox22.m_radius = ((weapon2.contentSize.width/2) / PTM_RATIO) * weapon2.scale;
    // Define the dynamic body fixture.
    b2FixtureDef fixtureDef22;
    fixtureDef22.shape = &dynamicBox2;	
    fixtureDef22.density = 100.0f;
    fixtureDef22.friction = 0.5f;
    body22->CreateFixture(&fixtureDef22);
    
    wep2.body = body22;
    
    wep.primaryWeapon = wep2;
    
    [self.entities addObject: wep2];
    
    [wep release];
    [wep2 release];
}

#pragma mark
#pragma mark Update Functions
-(void) draw
{
	// Default GL states: GL_TEXTURE_2D, GL_VERTEX_ARRAY, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
	// Needed states:  GL_VERTEX_ARRAY, 
	// Unneeded states: GL_TEXTURE_2D, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
	glDisable(GL_TEXTURE_2D);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	
	world->DrawDebugData();
	
    for (Entity * entity in self.entities) {
        if (entity.isValid) [entity draw];
    }
    
	// restore default GL states
	glEnable(GL_TEXTURE_2D);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    
}

-(void) tick: (ccTime) dt
{
    // once player reaches goal, kill all roaming entities -- for demo
    if ((self.score >= self.goalScore || hasReachedScore) && !hasSpawnedBoss) {
        hasReachedScore = YES;
        
        // must account for extra screen between transitions
        BOOL isGridSnapped = (NSInteger)self.pathGrid.position.x % (NSInteger)[self.pathGrid getOneScreenWidth] == 0 
        && ceil(fabs(self.pathGrid.position.x) / [self.pathGrid getOneScreenWidth] + 0.000001) == 1;//<= self.pathGrid.numberOfScreens;
        
        if (isGridSnapped && !hasSpawnedBoss) {
            [self unschedule:@selector(updateScrollingNodes)]; // stop scrolling
            // start spawning pathed bosses
            [self performSelector: @selector(spawnBoss) withObject:nil afterDelay:2.0];
            hasSpawnedBoss = YES;
        }
        
        for (Entity * entity in self.entities) {
            if (entity.entitySide & ENTITY_SIDE_ENEMY && entity.entityType != ENTITY_TYPE_PATHED) {
                entity.isValid = NO;
                entity.health = 0.0f;
            }
            
            // stop objects from scrolling
            if (entity.entityType == ENTITY_TYPE_WALL && isGridSnapped) {
                entity.isValid = NO;
            }
        }
        
        [self stopSpawning];
    }
    
	//It is recommended that a fixed time step is used with Box2D for stability
	//of the simulation, however, we are using a variable time step here.
	//You need to make an informed choice, the following URL is useful
	//http://gafferongames.com/game-physics/fix-your-timestep/
	
	int32 velocityIterations = 8;
	int32 positionIterations = 1;
	
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	world->Step(dt, velocityIterations, positionIterations);

	
	//Iterate over the bodies in the physics world
	for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
	{
		if (b->GetUserData() != NULL) {
			//Synchronize the AtlasSprites position and rotation with the corresponding body
            Entity * myActor = (Entity *)b->GetUserData();
			myActor.sprite.position = CGPointMake( b->GetPosition().x * PTM_RATIO, b->GetPosition().y * PTM_RATIO);
			myActor.sprite.rotation = -1 * CC_RADIANS_TO_DEGREES(b->GetAngle());
		}	
	}
}

- (void) updateScrollingNodes {
    [self.pathGrid updatePosition];
}

- (void) updateSpriteToBox: (ccTime) dt {
    // Animate player death and clean up
    if (!self.playerEntity.isValid && !self.playerEntity.isGameOver) {
        self.score-=100;
        // self.playerEntity.isValid = YES;
        [self cleanupWeaponRecurse: self.playerEntity];
        self.playerEntity.isGameOver = YES;
        
        [self performSelector: @selector(onMenu:) withObject:nil afterDelay: 3.0];
    }

    self.playerWeaponEntity.isValid = YES;
    
    [self.scoreLabel setString: [NSString stringWithFormat: @"%d/%d", self.score, self.goalScore]];
    
    for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
    {
        if (b->GetUserData() != NULL) {
            Entity * entity = (Entity *)b->GetUserData();
            
            if (entity.entityType == ENTITY_TYPE_NONE || entity.entityType == ENTITY_TYPE_WALL) {
                continue;
            }
            
            if (entity.isValid) {
                b2Vec2 b2Position = b2Vec2(entity.sprite.position.x/PTM_RATIO,
                                           entity.sprite.position.y/PTM_RATIO);
                float32 b2Angle = -1 * CC_DEGREES_TO_RADIANS(entity.sprite.rotation);
                
                b->SetTransform(b2Position, b2Angle);
            } else {
                // Remove invalid entities from our list, remove the associated sprite from our layer and remove
                // the body from our world
                if (!(entity.entitySide & ENTITY_SIDE_SELF)) {
                    entity.health -= 0.6 * self.playerWeaponEntity.sprite.scale;
                    if (entity.health <= 0) {
                        // Demo - win condition
                        if (entity.entityType == ENTITY_TYPE_PATHED) {
                            bossKillCount++;
                        }
                        
                        [self cleanupWeaponRecurse: entity];
                        self.score+=100;
                        
                    } else {
                        entity.isValid = YES;
                    }
                }
            }
        }
    }
    
    if (bossKillCount >= VICTORY_KILL_NUM) {
        // HAVE to remove these otherwise we crash
        [[[CCDirector sharedDirector] openGLView] removeGestureRecognizer:tappy];
        [[[CCDirector sharedDirector] openGLView] removeGestureRecognizer:tappy2];
        
        [tappy release];
        [tappy2 release];
        
        [[CCDirector sharedDirector] replaceScene:[WinScreenLayer scene]];     
    }
}

- (void) updateEntitiesPosition: (ccTime) dt {    
    for (Entity * entity in self.entities) {
        if (entity.isValid) [entity updatePosition: dt];
    }
    
    // for updating weapon position
    [self.playerEntity updatePosition: dt];
    self.streak.position = self.playerWeaponEntity.sprite.position;
 //   [self updateSpriteToBox: dt];
}

#pragma mark
#pragma mark Add Geometry
-(void) addRandomPolygons:(int)num {
	for(int i=0; i<num; i++){
		float x = (float)(arc4random()%((int)self.pathGrid.gameAreaSize.x*PTM_RATIO));
		float y = (float)(arc4random()%((int)self.pathGrid.gameAreaSize.y*PTM_RATIO));	
		
        // temporarily prevents geometry on spawn point
        if (x <= 150) {
            i--;
            continue;
        }
        
		[self addPolygonAtPoint:ccp(x,y)];
	}
}

-(void) addRandomBoxes:(int)num {
	for(int i=0; i<num; i++){
		float x = (float)(arc4random()%((int)self.pathGrid.gameAreaSize.x*PTM_RATIO));
		float y = (float)(arc4random()%((int)self.pathGrid.gameAreaSize.y*PTM_RATIO));	
		
        // temporarily prevents geometry on spawn point
        if (x <= 150) {
            i--;
            continue;
        }
        
		[self addBoxAtPoint:ccp(x,y) size:ccp((float)(arc4random()%200)+100.0f,(float)(arc4random()%50)+30.0f)];
	}
}

/* Adding a polygon */
-(void) addPolygonAtPoint:(CGPoint)p {
	//Random collection of points
	NSMutableArray *points = [[NSMutableArray alloc] init];
	for(int i=0; i<(arc4random()%5+3); i++){
		float x = (float)(arc4random()%100)+10;
		float y = (float)(arc4random()%100)+10;
		Vector3D *v = [Vector3D x:x y:y z:0];
		[points addObject:v];
	}
	
	//Convex polygon points
	NSMutableArray *convexPolygon = [GameHelper convexHull:points];
	
	//Convex Polygon
	float polygonSize = 0.05f;
    
	int32 numVerts = convexPolygon.count;
	b2Vec2 *vertices;
	vertices = new b2Vec2[convexPolygon.count];
	
	NSMutableArray *vertexArray = [[NSMutableArray alloc] init];
	
	CGPoint maxSize = ccp(0,0);
	for(int i=0; i<convexPolygon.count; i++){
		Vector3D *v = [convexPolygon objectAtIndex:i];
		vertices[i].Set(v.x*polygonSize, v.y*polygonSize);
		[vertexArray addObject:[NSValue valueWithCGPoint:ccp(v.x*PTM_RATIO*polygonSize, v.y*PTM_RATIO*polygonSize)]];
		
		//Figure out max polygon size
		if(maxSize.x < v.x*polygonSize){ maxSize.x = v.x*polygonSize; }
		if(maxSize.y < v.y*polygonSize){ maxSize.y = v.y*polygonSize; }
	}
	
	//Keep polygon in game area
	if(p.x/PTM_RATIO + maxSize.x > self.pathGrid.gameAreaSize.x){ p.x = (self.pathGrid.gameAreaSize.x - maxSize.x)*PTM_RATIO; }
	if(p.y/PTM_RATIO + maxSize.y > self.pathGrid.gameAreaSize.y){ p.y = (self.pathGrid.gameAreaSize.y - maxSize.y)*PTM_RATIO; }
	if(p.x < 0){ p.x = 0; }
	if(p.y < 0){ p.y = 0; }
    
	//GameMisc *obj = [[GameMisc alloc] init];
    ObjectEntity *obj = [[ObjectEntity alloc] init];
	//obj.gameArea = self;
	//obj.tag = GO_TAG_WALL;
    
    obj.bodyDef = new b2BodyDef();
	obj.bodyDef->type = b2_staticBody;
	obj.bodyDef->position.Set(p.x/PTM_RATIO, p.y/PTM_RATIO);
	obj.bodyDef->userData = obj;
	obj.body = world->CreateBody(obj.bodyDef);
	
	obj.polygonShape = new b2PolygonShape();
	obj.polygonShape->Set(vertices, numVerts);
    
    obj.fixtureDef = new b2FixtureDef();
	obj.fixtureDef->shape = obj.polygonShape;
	
	obj.body->CreateFixture(obj.fixtureDef);
    
    obj.gameAreaSize = self.pathGrid.gameAreaSize;
    obj.numberOfScreens = self.pathGrid.numberOfScreens;
    
#ifndef ORBIT_DEBUG_DISABLE_SCROLLING
    [self.entities addObject: obj];
#endif
}

/* Adding a polygon */
-(void) addBoxAtPoint:(CGPoint)p size:(CGPoint)s {
	//Random collection of points
	NSMutableArray *points = [[NSMutableArray alloc] init];
	float x = s.x; float y = s.y;
	
	[points addObject:[Vector3D x:0 y:0 z:0]];
	[points addObject:[Vector3D x:x y:0 z:0]];
	[points addObject:[Vector3D x:x y:y z:0]];
	[points addObject:[Vector3D x:0 y:y z:0]];
    
	float polygonSize = 0.05f;
    
	int32 numVerts = points.count;
	b2Vec2 *vertices;
	vertices = new b2Vec2[points.count];
	
	NSMutableArray *vertexArray = [[NSMutableArray alloc] init];
	
	CGPoint maxSize = ccp(0,0);
	for(int i=0; i<points.count; i++){
		Vector3D *v = [points objectAtIndex:i];
		vertices[i].Set(v.x*polygonSize, v.y*polygonSize);
		[vertexArray addObject:[NSValue valueWithCGPoint:ccp(v.x*PTM_RATIO*polygonSize, v.y*PTM_RATIO*polygonSize)]];
		
		//Figure out max polygon size
		if(maxSize.x < v.x*polygonSize){ maxSize.x = v.x*polygonSize; }
		if(maxSize.y < v.y*polygonSize){ maxSize.y = v.y*polygonSize; }
	}
	
	//Keep polygon in game area
	if(p.x/PTM_RATIO + maxSize.x > self.pathGrid.gameAreaSize.x){ p.x = (self.pathGrid.gameAreaSize.x - maxSize.x)*PTM_RATIO; }
	if(p.y/PTM_RATIO + maxSize.y > self.pathGrid.gameAreaSize.y){ p.y = (self.pathGrid.gameAreaSize.y - maxSize.y)*PTM_RATIO; }
	if(p.x < 0){ p.x = 0; }
	if(p.y < 0){ p.y = 0; }
    
	//GameMisc *obj = [[GameMisc alloc] init];
    ObjectEntity *obj = [[ObjectEntity alloc] init];
//	obj.gameArea = self;
//	obj.tag = GO_TAG_WALL;
    
    obj.bodyDef = new b2BodyDef();
	obj.bodyDef->type = b2_staticBody;
	obj.bodyDef->position.Set(p.x/PTM_RATIO, p.y/PTM_RATIO);
	obj.bodyDef->userData = obj;
	obj.body = world->CreateBody(obj.bodyDef);
	
	obj.polygonShape = new b2PolygonShape();
	obj.polygonShape->Set(vertices, numVerts);
    
    obj.fixtureDef = new b2FixtureDef();
	obj.fixtureDef->shape = obj.polygonShape;
	obj.fixtureDef->restitution = 0.0f;
	obj.fixtureDef->friction = 1.0f;
	
	obj.body->CreateFixture(obj.fixtureDef);

    obj.gameAreaSize = self.pathGrid.gameAreaSize;
    obj.numberOfScreens = self.pathGrid.numberOfScreens;

#ifndef ORBIT_DEBUG_DISABLE_SCROLLING
    [self.entities addObject: obj];
#endif
}

#pragma mark 
#pragma mark Device Input
- (void) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch * touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    
    location = [[CCDirector sharedDirector] convertToGL:location];
 //   NSLog(@"Touch Began");
    
    CCSprite * playerSprite = self.playerEntity.sprite;
    
    // If touch down is within the player
    if (location.x <= (playerSprite.position.x + playerSprite.contentSize.width/2) 
        && location.x >= (playerSprite.position.x - playerSprite.contentSize.width/2)
        && location.y <= (playerSprite.position.y + playerSprite.contentSize.height/2) 
        && location.y >= (playerSprite.position.y - playerSprite.contentSize.height/2)) {
        isMoving = YES;
    
       // [[CCDirector sharedDirector] resume];
    }
}

- (void) ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch * touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
 //   NSLog(@"Touch Moved w: %f h: %f", location.x, location.y);
    if (isMoving) {
        self.playerEntity.sprite.position = location;
    }
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
  //  NSLog(@"Touch Ended");
    isMoving = NO;
    
    //[[CCDirector sharedDirector] pause];
    
    /*
	//Add a new body/atlas sprite at the touched location
	for( UITouch *touch in touches ) {
		CGPoint location = [touch locationInView: [touch view]];
		
		location = [[CCDirector sharedDirector] convertToGL: location];
		
		[self addNewSpriteWithCoords: location];
	}
    */
}

- (void)accelerometer:(UIAccelerometer*)accelerometer didAccelerate:(UIAcceleration*)acceleration
{	
	static float prevX=0, prevY=0;
	
	//#define kFilterFactor 0.05f
#define kFilterFactor 1.0f	// don't use filter. the code is here just as an example
	
	float accelX = (float) acceleration.x * kFilterFactor + (1- kFilterFactor)*prevX;
	float accelY = (float) acceleration.y * kFilterFactor + (1- kFilterFactor)*prevY;
	
	prevX = accelX;
	prevY = accelY;
	
	// accelerometer values are in "Portrait" mode. Change them to Landscape left
	// multiply the gravity by 10
	b2Vec2 gravity( -accelY * 10, accelX * 10);
	
	world->SetGravity( gravity );
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	delete world;
	world = NULL;
	
	delete m_debugDraw;

    delete listener;
    
    [entities_ dealloc];
    [playerEntity_ release];
    [playerWeaponEntity_ release];
    [scoreLabel_ release];
    [weaponDamageLabel_ release];
    [weaponSpeedLabel_ release];
    [pathGrid_ release];
    [streak_ release];
    
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
