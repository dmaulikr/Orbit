//
//  SquareEntity.h
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Entity.h"

@interface SquareEntity : Entity {
    
}

@property (nonatomic, assign) BOOL rightDirection, leftDirection, upDirection, downDirection;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
@end
