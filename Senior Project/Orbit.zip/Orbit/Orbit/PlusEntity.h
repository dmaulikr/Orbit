//
//  PlusEntity.h
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Entity.h"

@interface PlusEntity : Entity {
    
}

@property (nonatomic, assign) BOOL topRightDirection, topLeftDirection, bottomRightDirection, bottomLeftDirection, 
    inwardDirection, isInCenter;
@property (nonatomic, assign) CGFloat heightIncrement, widthIncrement;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
@end
