//
//  WinScreenLayer.h
//  Orbit
//
//  Created by DAVID WATT on 3/16/12.
//  Copyright (c) 2012 Cal Poly - SLO. All rights reserved.
//

#import "CCLayer.h"
#import "cocos2d.h"

@interface WinScreenLayer : CCLayer {
    
}

// returns a CCScene that contains the MenuLayer as the only child
+ (CCScene *) scene;

- (void)onMenuItemTouched:(id)sender;
@end
