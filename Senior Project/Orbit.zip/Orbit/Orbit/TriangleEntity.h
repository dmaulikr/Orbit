//
//  TriangleEntity.h
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Entity.h"

@interface TriangleEntity : Entity {
    
}
@property (nonatomic, assign) BOOL topRightDirection, bottomRightDirection, middleLeftDirection;
@property (nonatomic, assign) CGFloat heightIncrement, widthIncrement;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
@end
