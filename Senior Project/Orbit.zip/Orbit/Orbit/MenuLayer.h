//
//  MenuLayer.h
//  Orbit
//
//  Created by Ken Hung on 1/12/12.
//  Copyright 2012 Cal Poly - SLO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MenuLayer : CCLayer {
    
}

// returns a CCScene that contains the MenuLayer as the only child
+ (CCScene *) scene;

- (void)onMenuItemTouched:(id)sender;
@end
