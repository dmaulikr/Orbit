//
//  Entity.h
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCSprite.h"
#import "Enums.h"
#import "CCDirector.h"
#import "Box2D.h"
#import "b2Body.h"
#import "Utils.h"

@class WeaponEntity;

@interface Entity : NSObject {
}

@property (nonatomic, retain) CCSprite * sprite;
@property (nonatomic, retain) CCSprite * healthSprite;
@property (nonatomic, readwrite) EntitySide entitySide;
@property (nonatomic, readwrite) EntityType entityType;
@property (nonatomic, assign) CGFloat speed;
@property (nonatomic, assign) CGFloat health;
@property (nonatomic, assign) BOOL isValid;
@property (nonatomic, retain) WeaponEntity * primaryWeapon;

// Box2D Pointers
@property (nonatomic, assign) b2Body * body;
@property (nonatomic, assign) b2BodyDef *bodyDef;
@property (nonatomic, assign) b2FixtureDef *fixtureDef;
@property (nonatomic, assign) b2PolygonShape *polygonShape;
@property (nonatomic, assign) b2CircleShape *circleShape;

- (void) updatePosition: (ccTime) dt;
- (void) draw;
@end
