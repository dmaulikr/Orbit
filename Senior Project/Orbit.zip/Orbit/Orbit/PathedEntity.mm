//
//  PathedEntity.m
//  Orbit
//
//  Created by Ken Hung on 2/12/12.
//  Copyright (c) 2012 Cal Poly - SLO. All rights reserved.
//

#import "PathedEntity.h"
#import "GameWaypoint.h"
#import "GameHelper.h"
#import "AStarNode.h"
#import "AStarPathNode.h"
#import "Utils.h"

#define WAYPOINT_DIST_THRESHOLD 16.0f
#define TIMES_BLOCKED_FAIL 2

@interface PathedEntity ()
    -(void) processWaypoints;
    -(void) runWithVector:(CGPoint)v withSpeedMod:(float)speedMod withConstrain:(bool)constrain;
    -(void) stopRunning;
    -(CGPoint) getNormalVectorFromDirection:(int)dir;
@end

@implementation PathedEntity
@synthesize gridLayer, waypoints, direction, runSpeed, lastVelocity;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side gameGrid: (GridLayer *) grid;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = ENTITY_TYPE_PATHED;
        
        self.gridLayer = grid;
        
    /*    self->rotation = 0.0;
        
        CGSize screenSize = [CCDirector sharedDirector].winSize;
        self->centerPoint.x = screenSize.width / 2;
        self->centerPoint.y = screenSize.height / 2;
        
        if (screenSize.width < screenSize.height) // assume sprite is square
            self->radius = screenSize.width / 2 - (self.sprite.contentSize.width / 2);
        else
            self->radius = screenSize.height / 2 - (self.sprite.contentSize.width / 2);*/
        self.waypoints = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
  /*  self->rotation += self.speed;
    
    if (self->rotation >= 360) {
        self->rotation-=360;
    }
    
    float rotInRad = (M_PI/180) * self->rotation;
    
    CGFloat x = cos(rotInRad);
    CGFloat y = sin(rotInRad);
    
    x *= self->radius;
    y *= self->radius;
    
    self.sprite.position = CGPointMake(self->centerPoint.x + x, self->centerPoint.y + y);
   */
    if ([self.waypoints count] == 0) {
        [self addWaypoint];
    }

    [self processWaypoints];
    self.healthSprite.position = self.sprite.position;
    
    [self.primaryWeapon updatePosition: dt];
}

- (void) draw {
#ifdef ORBIT_DEBUG_ENABLE_PATHING
    //Draw waypoints
	glColor4ub(255,255,0,32);
	CGPoint selfPosition = ccp(self.body->GetPosition().x*PTM_RATIO, self.body->GetPosition().y*PTM_RATIO);
	if(self.waypoints.count == 1){
		GameWaypoint *gw = (GameWaypoint*)[self.waypoints objectAtIndex:0];
		ccDrawLine(selfPosition, gw.position);
	}else if(self.waypoints.count > 1){
		for(int i=0; i<self.waypoints.count-1; i++){			
			GameWaypoint *gw = (GameWaypoint*)[self.waypoints objectAtIndex:i];
			GameWaypoint *gwNext = (GameWaypoint*)[self.waypoints objectAtIndex:i+1];
			
			if(i == 0){
				//From self to first waypoint
				ccDrawLine(selfPosition, gw.position);
				ccDrawLine(gw.position, gwNext.position);
			}else{
				//From this waypoint to next one
				ccDrawLine(gw.position, gwNext.position);
			}	
		}
	}
	glColor4ub(255,255,255,255);

    glColor4ub(255,0,0,255);
    for (GameWaypoint * wp in self.waypoints) {
     //   NSLog(@"%f %f", wp.position.x, wp.position.y);
        ccDrawCircle(wp.position, 35, 0, 4, NO);
    }
    glColor4ub(255,255,255,255);
#endif
}

-(void) processWaypoints {
	bool removeFirstWaypoint = NO;
	
	//The actor's position onscreen
	CGPoint worldPosition = CGPointMake(self.body->GetPosition().x * PTM_RATIO, self.body->GetPosition().y * PTM_RATIO);
	
	//Process waypoints 
	for(GameWaypoint *wp in waypoints){
		float distanceToNextPoint = [GameHelper distanceP1:worldPosition toP2:CGPointMake(wp.position.x, wp.position.y)];
		
		//If we didn't make progress to the next point, increment timesBlocked
		if(distanceToNextPoint >= wp.lastDistance){
			timesBlocked++;
			
			//Drop this waypoint if we failed to move a number of times
			if(timesBlocked > TIMES_BLOCKED_FAIL){
				distanceToNextPoint = 0.0f;
			}
		}else{
			//If we are just starting toward this point we run our pre-callback
			wp.lastDistance = distanceToNextPoint;
			[wp processPreCallback];
		}
        
		//If we are close enough to the waypoint we move onto the next one
		if(distanceToNextPoint <= WAYPOINT_DIST_THRESHOLD){
			removeFirstWaypoint = YES;
			[self stopRunning];
			
			//Run post callback
			[wp processPostCallback];
		}else{
			//Keep running toward the waypoint
			float speedMod = wp.speedMod;
			
			//Slow down close to the waypoint
			if(distanceToNextPoint < [self runSpeed]/PTM_RATIO){
				speedMod = (distanceToNextPoint)/([self runSpeed]/PTM_RATIO);
			}
			[self runWithVector:ccp(wp.position.x - worldPosition.x, wp.position.y - worldPosition.y) withSpeedMod:speedMod withConstrain:NO ];
			break;
		}
	}
	if(removeFirstWaypoint){
		[waypoints removeObjectAtIndex:0];
		timesBlocked = 0;
	}
}

-(void) runWithVector:(CGPoint)v withSpeedMod:(float)speedMod withConstrain:(bool)constrain {	
	//Change animation depending on angle
	float radians = [GameHelper vectorToRadians:v];
	float degrees = [GameHelper radiansToDegrees:radians];
	CGPoint constrainedVector;	//Vector constained to only the 8 angles
	CGPoint unconstrainedVector = [GameHelper radiansToVector:radians];	//Unconstrained vector
    
	degrees += 90.0f;
    
	if(degrees >= 337.5f || degrees < 22.5f){
		direction = LEFT;
	}else if(degrees >= 22.5f && degrees < 67.5f){
		direction = UP_LEFT;
	}else if(degrees >= 67.5f && degrees < 112.5f){
		direction = UP;
	}else if(degrees >= 112.5f && degrees < 157.5f){
		direction = UP_RIGHT;
	}else if(degrees >= 157.5f && degrees < 202.5f){
		direction = RIGHT;
	}else if(degrees >= 202.5f && degrees < 247.5f){
		direction = DOWN_RIGHT;
	}else if(degrees >= 247.5f && degrees < 292.5f){
		direction = DOWN;
	}else{
		direction = DOWN_LEFT;
	}
	
	constrainedVector = [self getNormalVectorFromDirection:direction];
    
	if(constrain){
            self.sprite.position = ccp(self.sprite.position.x + constrainedVector.x * self.speed, self.sprite.position.y + constrainedVector.y * self.speed);
	//	self.body->SetLinearVelocity(b2Vec2(constrainedVector.x*runSpeed*speedMod, constrainedVector.y*runSpeed*speedMod));
	}else{
            self.sprite.position = ccp(self.sprite.position.x + constrainedVector.x * self.speed, self.sprite.position.y + constrainedVector.y * self.speed);
	//	self.body->SetLinearVelocity(b2Vec2(unconstrainedVector.x*runSpeed*speedMod, unconstrainedVector.y*runSpeed*speedMod));
	}
	
	if(lastAngularVelocity != 0.0f && lastAngularVelocity == self.body->GetAngularVelocity()){
		self.body->SetAngularVelocity(0.0f);
	}
	lastAngularVelocity = self.body->GetAngularVelocity();
	lastVelocity = ccp(self.body->GetLinearVelocity().x, self.body->GetLinearVelocity().y);
}

-(void) stopRunning {
	self.body->SetLinearVelocity(b2Vec2(0.0f,0.0f));
}

-(CGPoint) getNormalVectorFromDirection:(int)dir{
	CGPoint v;
	if(dir == LEFT){
		v = ccp(-1,0);
	}else if(dir == UP_LEFT){
		v = ccp(-0.7071067812,0.7071067812);
	}else if(dir == UP){
		v = ccp(0,1);
	}else if(dir == UP_RIGHT){
		v = ccp(0.7071067812,0.7071067812);
	}else if(dir == RIGHT){
		v = ccp(1,0);
	}else if(dir == DOWN_RIGHT){
		v = ccp(0.7071067812,-0.7071067812);
	}else if(dir == DOWN){
		v = ccp(0,-1);
	}else if(dir == DOWN_LEFT){
		v = ccp(-0.7071067812,-0.7071067812);
	}
	return v;
}

- (void) addWaypoint {
    //Convert touch coordinate to physical coordinate
    NSInteger height = arc4random() % ((NSInteger)self.gridLayer.gameAreaSize.y*PTM_RATIO);
    
    // rand 0 - 1 screen length
    NSInteger randOneScreenLength = arc4random() % (NSInteger)([self.gridLayer getOneScreenWidth]);
    NSInteger width = (([self.gridLayer getOneScreenWidth] * [self.gridLayer getCurrentScreenNumber]) + randOneScreenLength);
	// NSInteger width = (arc4random() % (NSInteger)(self.gridLayer.gameAreaSize.x*PTM_RATIO));
    
    NSLog(@"Waypoint Added: %d %d %f %d %d", width, height, [self.gridLayer getOneScreenWidth], [self.gridLayer getCurrentScreenNumber], randOneScreenLength);
    NSLog(@"grid position: %f", self.gridLayer.position.x);
    
    CGPoint endPoint = ccp(width, height);//[self convertTouchCoord:point];
    
	if(endPoint.x < 0 || endPoint.y < 0 || endPoint.x >= self.gridLayer.gameAreaSize.x*PTM_RATIO || endPoint.y >= self.gridLayer.gameAreaSize.y*PTM_RATIO){
		return;
	}
	
	//Actor position
	CGPoint actorPosition = ccp(self.body->GetPosition().x*PTM_RATIO, self.body->GetPosition().y*PTM_RATIO);
	
	//We use the last waypoint position if applicable
	if(self.waypoints.count > 0){
		actorPosition = [[self.waypoints objectAtIndex:self.waypoints.count-1] position];
	}
	
	//Starting node
	AStarNode *startNode = [[self.gridLayer.grid objectAtIndex:(int)(actorPosition.x/self.gridLayer.nodeSpace)] objectAtIndex:(int)(actorPosition.y/self.gridLayer.nodeSpace)];
    
	//Make sure the start node is actually properly connected
	if(startNode.neighbors.count == 0){
		bool found = NO; float n = 1;
		while(!found){
			//Search the nodes around this point for a properly connected starting node
			for(float x = -n; x<= n; x+= n){
				for(float y = -n; y<= n; y+= n){
					if(x == 0 && y == 0){ continue; }
					float xIndex = ((int)(actorPosition.x/self.gridLayer.nodeSpace))+x;
					float yIndex = ((int)(actorPosition.y/self.gridLayer.nodeSpace))+y;
					if(xIndex >= 0 && yIndex >= 0 && xIndex < self.gridLayer.gridSizeX && yIndex < self.gridLayer.gridSizeY){
						AStarNode *node = [[self.gridLayer.grid objectAtIndex:xIndex] objectAtIndex:yIndex];
						if(node.neighbors.count > 0){
							startNode = node;
							found = YES;
							break; break;
						}
					}					
				}
			}
			n += 1;
		}
	}
	
	//End node
	AStarNode *endNode = [[self.gridLayer.grid objectAtIndex:(int)(endPoint.x/self.gridLayer.nodeSpace)] objectAtIndex:(int)(endPoint.y/self.gridLayer.nodeSpace)];	
    
	//Run the pathfinding algorithm
	NSMutableArray *foundPath = [AStarPathNode findPathFrom:startNode to:endNode];
	
	if(!foundPath){
	//	[self showMessage:@"No Path Found"];
        NSLog(@"No Path Found");
    }else{
	//	[self showMessage:@"Found Path"];
        NSLog(@"Path Found");
		//Add found path as a waypoint set to the actor
		for(int i=foundPath.count-1; i>=0; i--){
			CGPoint pathPoint = [[foundPath objectAtIndex:i] CGPointValue];
			[self.waypoints addObject: [GameWaypoint createWithPosition:pathPoint withSpeedMod:1.0f]];
		}
	}
	
	[foundPath release]; 
    foundPath = nil;
}

- (void) dealloc {
    gridLayer = nil;
    [waypoints release];
    
    [super dealloc];
}
@end
