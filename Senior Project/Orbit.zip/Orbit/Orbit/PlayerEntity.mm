//
//  PlayerEntity.m
//  Orbit
//
//  Created by Ken Hung on 1/10/12.
//  Copyright (c) 2012 Cal Poly - SLO. All rights reserved.
//

#import "PlayerEntity.h"

@implementation PlayerEntity
@synthesize isGameOver;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side entityType: (EntityType) type;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = type;
        
        self.isGameOver = NO;
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    if (self.isValid) {
        [super updatePosition: dt];
        [self.primaryWeapon updatePosition: dt];
    }
}

- (void) dealloc {
    [super dealloc];
}

@end
