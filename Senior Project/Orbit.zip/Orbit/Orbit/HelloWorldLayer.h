//
//  HelloWorldLayer.h
//  Orbit
//
//  Created by Ken Hung on 8/20/11.
//  Copyright Cal Poly - SLO 2011. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "Box2D.h"
#import "GLES-Render.h"
#import "MyContactListener.h"
#import "PlayerEntity.h"
#import "WeaponEntity.h"

#import "GridLayer.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer
{
	b2World* world;
	GLESDebugDraw *m_debugDraw;
    
    // ---
    BOOL isMoving;
    
    MyContactListener * listener;
    b2Body * weaponBody;
    
    BOOL hasSpawnedBoss, hasReachedScore;
    NSInteger spawnCount;
    NSInteger bossKillCount;
}

@property (nonatomic, retain) NSMutableArray * entities;
@property (nonatomic, retain) PlayerEntity * playerEntity;
@property (nonatomic, retain) CCMotionStreak * streak;
@property (nonatomic, retain) WeaponEntity * playerWeaponEntity;
@property (nonatomic, retain) CCLabelTTF * scoreLabel, * weaponSpeedLabel, * weaponDamageLabel;
@property (nonatomic, assign) NSInteger score, goalScore;

@property (nonatomic, retain) GridLayer * pathGrid;

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;
// adds a new sprite at a given coordinate
-(void) addNewSpriteWithCoords:(CGPoint)p;

-(void) initPlayer;
-(void) initSquare;
-(void) initTriangle;
-(void) initLine;
-(void) initPlus;
-(void) initCircle;
-(void) initPathed;

- (void) stopSpawning;
- (void) spawnBoss;

- (void) updateScrollingNodes;

- (void) updateSpriteToBox:(ccTime)dt;

- (void) onMenu:(id) sender;

- (void) cleanupWeaponRecurse: (Entity *) entity;

- (void) addRandomPolygons:(int)num;
- (void) addRandomBoxes:(int)num;
- (void) addPolygonAtPoint:(CGPoint)p;
- (void) addBoxAtPoint:(CGPoint)p size:(CGPoint)s;

- (void) animateParticleDeathAtPosition: (CGPoint) position;
@end
