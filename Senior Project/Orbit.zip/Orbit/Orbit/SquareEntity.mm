//
//  SquareEntity.m
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import "SquareEntity.h"

@implementation SquareEntity
@synthesize rightDirection = rightDirection_, leftDirection = leftDirection_, upDirection = upDirection_, 
    downDirection = downDirection_;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = ENTITY_TYPE_SQUARE;
        
        self.rightDirection = NO;
        self.leftDirection = NO;
        self.upDirection = NO;
        self.downDirection = NO;
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    
    CGFloat xPos = self.sprite.position.x;
    CGFloat yPos = self.sprite.position.y;
    
    CGFloat squareWidth = self.sprite.contentSize.width;
    CGFloat squareHeight = self.sprite.contentSize.height;
    
    if (self.upDirection) {
        yPos += self.speed;
        
        if (yPos + squareHeight/2 >= screenSize.height) {
            self.rightDirection = YES;
            self.upDirection = NO;
        }
    } else if (self.downDirection) {
        yPos -= self.speed;
        
        if (yPos - squareHeight/2 <= 0) {
            self.leftDirection = YES;
            self.downDirection = NO;
        }
    } else if (self.rightDirection) {
        xPos += self.speed;
        
        if (xPos + squareWidth/2 >= screenSize.width) {
            self.downDirection = YES;
            self.rightDirection = NO;
        }
    } else if (self.leftDirection) {
        xPos -= self.speed;
        
        if (xPos - squareWidth/2 <= 0) {
            self.upDirection = YES;
            self.leftDirection = NO;
        }
    }
    
    self.sprite.position = CGPointMake(xPos, yPos);
    self.healthSprite.position = self.sprite.position;
}

- (void) dealloc {
    [super dealloc];
}
@end
