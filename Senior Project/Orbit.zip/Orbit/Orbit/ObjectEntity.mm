//
//  ObjectEntity.m
//  Orbit
//
//  Created by Ken Hung on 2/20/12.
//  Copyright (c) 2012 Cal Poly - SLO. All rights reserved.
//

#import "ObjectEntity.h"
#import "ccMacros.h"

@implementation ObjectEntity
@synthesize gameAreaSize, numberOfScreens;

- (id) init {
    if ((self = [super init])) {
        self.entityType = ENTITY_TYPE_WALL;
        self.gameAreaSize = CGPointZero;
        self.numberOfScreens = 1;
        
        positionOffset = 0;
        originalPosition = CGPointMake(-1, -1);
    }

    return self;
}

- (void) updatePosition:(ccTime)dt {
    b2Body * objBody = self.body;
    b2Vec2 b2Position;
    
    if (originalPosition.x == -1 && originalPosition.y == -1) {
        originalPosition = CGPointMake(self.body->GetPosition().x * PTM_RATIO, self.body->GetPosition().y * PTM_RATIO);
    }
    
    if (positionOffset <= -self.gameAreaSize.x * PTM_RATIO) {
        positionOffset = self.gameAreaSize.x * PTM_RATIO / self.numberOfScreens;
    } else {
        positionOffset -= 4; // use 4 becuase it divide nicely into screen width
    }
    
    b2Position = b2Vec2((originalPosition.x + positionOffset) / PTM_RATIO, objBody->GetPosition().y);
    
    float32 b2Angle = -1 * CC_DEGREES_TO_RADIANS(self.sprite.rotation);
    
    objBody->SetTransform(b2Position, b2Angle);    
}

@end
