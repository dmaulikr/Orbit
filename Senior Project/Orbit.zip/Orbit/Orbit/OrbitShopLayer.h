//
//  OrbitShopLayer.h
//  Orbit
//
//  Created by Ken Hung on 9/5/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface OrbitShopLayer : CCLayer {
    
}
+(CCScene*) scene;
@end
