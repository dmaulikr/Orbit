//
//  LineEntity.m
//  Orbit
//
//  Created by Ken Hung on 8/28/11.
//  Copyright 2011 Cal Poly - SLO. All rights reserved.
//

#import "LineEntity.h"


@implementation LineEntity
@synthesize leftDirection = leftDirection_;

- (id) initWithSprite: (CCSprite *) sprite entitySide: (EntitySide) side;
{
	if ((self = [super init])) {
        self.sprite = sprite;
        self.entitySide = side;
        self.entityType = ENTITY_TYPE_LINE;
        
        self.leftDirection = NO;
    }
    
    return self;
}

- (void) updatePosition: (ccTime) dt {
    [super updatePosition: dt];
    
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    
    CGFloat xPos = self.sprite.position.x;
    if (xPos - (self.sprite.contentSize.width / 2) <= 0) {
        self.leftDirection = NO;
    } else if (xPos + (self.sprite.contentSize.width / 2) >= screenSize.width) {
        self.leftDirection = YES;
    }
    
    if (self.leftDirection) {
        xPos = self.sprite.position.x - self.speed;
    } else {
        xPos = self.sprite.position.x + self.speed;
    }
    
    self.sprite.position = CGPointMake(xPos, self.sprite.position.y);
    self.healthSprite.position = self.sprite.position;
}

- (void) dealloc {
    [super dealloc];
}
@end
