//
//  MenuLayer.m
//  Orbit
//
//  Created by Ken Hung on 1/12/12.
//  Copyright 2012 Cal Poly - SLO. All rights reserved.
//

#import "MenuLayer.h"
#import "HelloWorldLayer.h"
#import "OrbitShopLayer.h"

@implementation MenuLayer
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MenuLayer *layer = [MenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init {
    if (self = [super init]) {
        self.isTouchEnabled = YES;
        
        CGSize screenSize = [CCDirector sharedDirector].winSize;

        // Demo Instructions
        CCLabelTTF * label = [CCLabelTTF labelWithString: @"Demo Information" fontName: @"Arial" fontSize:28];
        [label setColor:ccc3(255, 150, 150)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 200);
        [self addChild: label z: 1];
        
        label = [CCLabelTTF labelWithString: @"- You can move your character (the red circle) with your finger." fontName: @"Arial" fontSize:22];
        [label setColor:ccc3(255, 255, 255)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 175);
        [self addChild: label z: 1];
        
        label = [CCLabelTTF labelWithString: @"- Tap with 1 finger to increase weapon speed (Costs 200 score)" fontName: @"Arial" fontSize:22];
        [label setColor:ccc3(255, 255, 255)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 150);
        [self addChild: label z: 1];
        
        label = [CCLabelTTF labelWithString: @"- Tap with 2 fingers to increase weapon damage (Costs 300 score)" fontName: @"Arial" fontSize:22];
        [label setColor:ccc3(255, 255, 255)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 125);
        [self addChild: label z: 1];
        
        label = [CCLabelTTF labelWithString: @"- The gaol is to reach a target score that will be located at the top left of the screen." fontName: @"Arial" fontSize:22];
        [label setColor:ccc3(255, 255, 255)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 100);
        [self addChild: label z: 1];
        
        label = [CCLabelTTF labelWithString: @"and defeat the \'boss\' at the end." fontName: @"Arial" fontSize:22];
        [label setColor:ccc3(255, 255, 255)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 75);
        [self addChild: label z: 1];
        
        label = [CCLabelTTF labelWithString: @"NOTE: You only have 1 life, but you may retry as many times as you like." fontName: @"Arial" fontSize:22];
        [label setColor:ccc3(255, 255, 255)];
        label.position = ccp(screenSize.width / 2, screenSize.height / 2 + 50);
        [self addChild: label z: 1];
        
        
        CCMenuItemFont * menuItemFontPlay = [CCMenuItemFont itemFromString:@"Play" target:self selector:@selector(onMenuItemTouched:)];
        menuItemFontPlay.tag = 1;
        CCMenuItem * menuItemPlay = menuItemFontPlay;
        
        CCMenuItemFont * menuItemFontShop = [CCMenuItemFont itemFromString:@"Shop" target:self selector:@selector(onMenuItemTouched:)];
        menuItemFontShop.tag = 2;
        CCMenuItem * menuItemShop = menuItemFontShop;
        
        CCMenu *menu = [CCMenu menuWithItems:menuItemPlay, menuItemShop, nil];
        [menu alignItemsVertically];
        [self addChild:menu];
    }
    
    return self;
}

- (void)onMenuItemTouched:(id)sender;
{
    NSLog(@"on play %@", [sender description]);
    if ([sender isKindOfClass: [CCMenuItemFont class]]) {
        CCMenuItemFont * menuItem = (CCMenuItemFont *)sender;
        
        switch (menuItem.tag) {
            case 1:
                [[CCDirector sharedDirector] replaceScene:[HelloWorldLayer scene]];       
                break;
            case 2:
                [[CCDirector sharedDirector] replaceScene:[OrbitShopLayer scene]];   
                break;
            case 3:
                // [[CCDirector sharedDirector] replaceScene:[HelloWorldLayer scene]];   
                break;
            default:
                break;
        }
    }
}

@end
